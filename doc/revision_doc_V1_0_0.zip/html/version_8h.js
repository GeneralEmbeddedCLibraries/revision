var version_8h =
[
    [ "VER_VER_DEVELOP", "group___v_e_r_s_i_o_n.html#gac879dc53837908fe2367cd71226ff1c3", null ],
    [ "VER_VER_MAJOR", "group___v_e_r_s_i_o_n.html#ga771006eeb57d76356b98d303bcdb8061", null ],
    [ "VER_VER_MINOR", "group___v_e_r_s_i_o_n.html#gab87a93673ea8a610b408fdf5b4b8131c", null ],
    [ "version_get_hw", "group___v_e_r_s_i_o_n.html#ga21c28cf18bf1635ce9ab34b3f46b17e8", null ],
    [ "version_get_hw_str", "group___v_e_r_s_i_o_n.html#ga5bbbf6f3d0a78ba7eb09eef04511ff82", null ],
    [ "version_get_sw", "group___v_e_r_s_i_o_n.html#ga462ccf867d00cc0aedb5d79997f39c2e", null ],
    [ "version_get_sw_str", "group___v_e_r_s_i_o_n.html#ga4221c2b4e4e80dc2965f518aa2dcecd9", null ]
];