var group___v_e_r_s_i_o_n =
[
    [ "ver_app_header_t", "structver__app__header__t.html", [
      [ "app_crc", "structver__app__header__t.html#aab8f9e40669f88c9dc1062723bd33fa7", null ],
      [ "app_size", "structver__app__header__t.html#a2330e636b55363ea3f57430c820be1f3", null ],
      [ "signature", "structver__app__header__t.html#a165b448c1ebb4c4ca84a16ee87671d8f", null ],
      [ "sw_dev", "structver__app__header__t.html#abdbbf22cb0cfd8669079f84344c4aa01", null ],
      [ "sw_major", "structver__app__header__t.html#a3781c55f8b15207c3f6beaf1676afd77", null ],
      [ "sw_minor", "structver__app__header__t.html#ae05dd3828c658190723c568519429215", null ],
      [ "sw_test", "structver__app__header__t.html#a5dfc1972b23231f7a0373575bcd43045", null ]
    ] ],
    [ "VER_VER_DEVELOP", "group___v_e_r_s_i_o_n.html#gac879dc53837908fe2367cd71226ff1c3", null ],
    [ "VER_VER_MAJOR", "group___v_e_r_s_i_o_n.html#ga771006eeb57d76356b98d303bcdb8061", null ],
    [ "VER_VER_MINOR", "group___v_e_r_s_i_o_n.html#gab87a93673ea8a610b408fdf5b4b8131c", null ],
    [ "VERSION_HW", "group___v_e_r_s_i_o_n.html#ga76a16e110cb2403aa00efa5a06840229", null ],
    [ "VERSION_SW", "group___v_e_r_s_i_o_n.html#ga4677ebbc5bd6b2ad131b3fdfdbbff3c1", null ],
    [ "version_get_hw", "group___v_e_r_s_i_o_n.html#ga21c28cf18bf1635ce9ab34b3f46b17e8", null ],
    [ "version_get_hw_str", "group___v_e_r_s_i_o_n.html#ga5bbbf6f3d0a78ba7eb09eef04511ff82", null ],
    [ "version_get_sw", "group___v_e_r_s_i_o_n.html#ga462ccf867d00cc0aedb5d79997f39c2e", null ],
    [ "version_get_sw_str", "group___v_e_r_s_i_o_n.html#ga4221c2b4e4e80dc2965f518aa2dcecd9", null ],
    [ "VERSION_HW", "group___v_e_r_s_i_o_n.html#gae128a5b2cf91cdd17bdc20303667b5fc", null ],
    [ "VERSION_SW", "group___v_e_r_s_i_o_n.html#gadd212cadbf3a6d40962353cdb0ddc96c", null ]
];