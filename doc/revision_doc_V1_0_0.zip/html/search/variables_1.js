var searchData=
[
  ['signature_31',['signature',['../structver__app__header__t.html#a165b448c1ebb4c4ca84a16ee87671d8f',1,'ver_app_header_t']]],
  ['sw_5fdev_32',['sw_dev',['../structver__app__header__t.html#abdbbf22cb0cfd8669079f84344c4aa01',1,'ver_app_header_t']]],
  ['sw_5fmajor_33',['sw_major',['../structver__app__header__t.html#a3781c55f8b15207c3f6beaf1676afd77',1,'ver_app_header_t']]],
  ['sw_5fminor_34',['sw_minor',['../structver__app__header__t.html#ae05dd3828c658190723c568519429215',1,'ver_app_header_t']]],
  ['sw_5ftest_35',['sw_test',['../structver__app__header__t.html#a5dfc1972b23231f7a0373575bcd43045',1,'ver_app_header_t']]]
];
