var searchData=
[
  ['app_5fcrc_29',['app_crc',['../structver__app__header__t.html#aab8f9e40669f88c9dc1062723bd33fa7',1,'ver_app_header_t']]],
  ['app_5fsize_30',['app_size',['../structver__app__header__t.html#a2330e636b55363ea3f57430c820be1f3',1,'ver_app_header_t']]]
];
