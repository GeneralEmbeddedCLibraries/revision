var indexSectionsWithContent =
{
  0: "asv",
  1: "v",
  2: "v",
  3: "v",
  4: "as",
  5: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Modules"
};

