var version_8c =
[
    [ "VERSION_HW", "group___v_e_r_s_i_o_n.html#ga76a16e110cb2403aa00efa5a06840229", null ],
    [ "VERSION_SW", "group___v_e_r_s_i_o_n.html#ga4677ebbc5bd6b2ad131b3fdfdbbff3c1", null ],
    [ "version_get_hw", "group___v_e_r_s_i_o_n.html#ga21c28cf18bf1635ce9ab34b3f46b17e8", null ],
    [ "version_get_hw_str", "group___v_e_r_s_i_o_n.html#ga5bbbf6f3d0a78ba7eb09eef04511ff82", null ],
    [ "version_get_sw", "group___v_e_r_s_i_o_n.html#ga462ccf867d00cc0aedb5d79997f39c2e", null ],
    [ "version_get_sw_str", "group___v_e_r_s_i_o_n.html#ga4221c2b4e4e80dc2965f518aa2dcecd9", null ],
    [ "VERSION_HW", "group___v_e_r_s_i_o_n.html#gae128a5b2cf91cdd17bdc20303667b5fc", null ],
    [ "VERSION_SW", "group___v_e_r_s_i_o_n.html#gadd212cadbf3a6d40962353cdb0ddc96c", null ]
];