var annotated_dup =
[
    [ "ver_app_header_t", "structver__app__header__t.html", "structver__app__header__t" ]
];