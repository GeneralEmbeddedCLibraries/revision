var structver__app__header__t =
[
    [ "app_crc", "structver__app__header__t.html#aab8f9e40669f88c9dc1062723bd33fa7", null ],
    [ "app_size", "structver__app__header__t.html#a2330e636b55363ea3f57430c820be1f3", null ],
    [ "signature", "structver__app__header__t.html#a165b448c1ebb4c4ca84a16ee87671d8f", null ],
    [ "sw_dev", "structver__app__header__t.html#abdbbf22cb0cfd8669079f84344c4aa01", null ],
    [ "sw_major", "structver__app__header__t.html#a3781c55f8b15207c3f6beaf1676afd77", null ],
    [ "sw_minor", "structver__app__header__t.html#ae05dd3828c658190723c568519429215", null ],
    [ "sw_test", "structver__app__header__t.html#a5dfc1972b23231f7a0373575bcd43045", null ]
];